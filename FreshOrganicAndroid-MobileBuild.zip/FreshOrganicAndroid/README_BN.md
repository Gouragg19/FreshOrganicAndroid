# Fresh Organic Android Project

এটি Fresh Organic-এর একটি প্রাথমিক native Android (Kotlin + Jetpack Compose) ডেমো প্রজেক্ট।

## অন্তর্ভুক্ত
- শুধু শসা ও ঝিঙে
- প্রাথমিক দাম: শসা ₹৩০/কেজি, ঝিঙে ₹৪০/কেজি
- Cart ও পরিমাণ পরিবর্তন
- Home Delivery ₹২০, Shop Pickup ফ্রি
- COD ও UPI পদ্ধতি নির্বাচন (ডেমো; আসল পেমেন্ট নয়)
- Admin স্ক্রিনে পণ্যের দাম পরিবর্তন (শুধু চলতি সেশনে)

## Android Studio-তে চালানো
1. Android Studio ইনস্টল করুন।
2. `FreshOrganic` ফোল্ডারটি Open করুন।
3. Gradle Sync সম্পূর্ণ হতে দিন (ইন্টারনেট লাগবে)।
4. Android Emulator বা USB debugging চালু করা ফোন নির্বাচন করে Run চাপুন।
5. APK বানাতে: **Build > Build Bundle(s) / APK(s) > Build APK(s)**।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনো production app নয়। Firebase/ব্যাকএন্ড, বাস্তব OTP, স্থায়ী ডেটাবেস, অর্ডার সার্ভার, আসল UPI payment gateway, নিরাপদ Admin login এবং push notification যুক্ত হয়নি। UPI অপশনটি কেবল UI demo।
