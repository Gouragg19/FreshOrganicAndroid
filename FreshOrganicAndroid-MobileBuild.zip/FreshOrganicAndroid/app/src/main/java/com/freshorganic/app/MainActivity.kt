package com.freshorganic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF218838)
private val Pale = Color(0xFFEAF6EC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FreshOrganicApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FreshOrganicApp() {
    var cucumberPrice by remember { mutableIntStateOf(30) }
    var ridgePrice by remember { mutableIntStateOf(40) }
    var cucumberQty by remember { mutableIntStateOf(0) }
    var ridgeQty by remember { mutableIntStateOf(0) }
    var delivery by remember { mutableStateOf("Home Delivery") }
    var payment by remember { mutableStateOf("Cash on Delivery") }
    var page by remember { mutableStateOf("Shop") }
    var orderMessage by remember { mutableStateOf("") }
    val subtotal = cucumberQty * cucumberPrice + ridgeQty * ridgePrice
    val deliveryFee = if (delivery == "Home Delivery") 20 else 0

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Green)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Fresh Organic", fontWeight = FontWeight.Bold, color = Green)
                            Text("তাজা সবজি, সহজ বাজার", fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    actions = { TextButton(onClick = { page = if (page == "Admin") "Shop" else "Admin" }) { Text(if (page == "Admin") "Shop" else "Admin") } }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = page == "Shop", onClick = { page = "Shop" }, icon = { Text("🥬") }, label = { Text("Shop") })
                    NavigationBarItem(selected = page == "Cart", onClick = { page = "Cart" }, icon = { Text("🛒") }, label = { Text("Cart") })
                    NavigationBarItem(selected = page == "Admin", onClick = { page = "Admin" }, icon = { Text("⚙") }, label = { Text("Admin") })
                }
            }
        ) { padding ->
            when (page) {
                "Admin" -> LazyColumn(Modifier.padding(padding).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item { Text("Admin Panel", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Green) }
                    item { Text("দৈনিক পণ্যের দাম পরিবর্তন করুন") }
                    item { PriceEditor("শসা", cucumberPrice) { cucumberPrice = it } }
                    item { PriceEditor("ঝিঙে", ridgePrice) { ridgePrice = it } }
                    item { Text("এই ডেমোতে দাম শুধু এই ডিভাইসের চলতি সেশনে থাকবে। স্থায়ী সংরক্ষণের জন্য ডেটাবেস লাগবে।", color = Color.Gray, fontSize = 12.sp) }
                }
                "Cart" -> LazyColumn(Modifier.padding(padding).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item { Text("আপনার Cart", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Green) }
                    item { Text("শসা: $cucumberQty কেজি × ₹$cucumberPrice = ₹${cucumberQty * cucumberPrice}") }
                    item { Text("ঝিঙে: $ridgeQty কেজি × ₹$ridgePrice = ₹${ridgeQty * ridgePrice}") }
                    item { Divider() }
                    item { Text("ডেলিভারি পদ্ধতি", fontWeight = FontWeight.Bold) }
                    item { Choice("Home Delivery · ₹20", delivery == "Home Delivery") { delivery = "Home Delivery" } }
                    item { Choice("Shop Pickup · Free", delivery == "Shop Pickup") { delivery = "Shop Pickup" } }
                    item { Text("Payment Method", fontWeight = FontWeight.Bold) }
                    item { Choice("Cash on Delivery (COD)", payment == "Cash on Delivery") { payment = "Cash on Delivery" } }
                    item { Choice("UPI (Google Pay / PhonePe)", payment == "UPI") { payment = "UPI" } }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Pale)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("পণ্যের দাম: ₹$subtotal")
                                Text("ডেলিভারি চার্জ: ₹$deliveryFee")
                                Text("সর্বমোট: ₹${subtotal + deliveryFee}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Green)
                            }
                        }
                    }
                    item { Button(onClick = { orderMessage = if (subtotal > 0) "ডেমো অর্ডার তৈরি হয়েছে!\nপদ্ধতি: $delivery\nপেমেন্ট: $payment\nমোট: ₹${subtotal + deliveryFee}" else "প্রথমে Cart-এ পণ্য যোগ করুন" }, modifier = Modifier.fillMaxWidth()) { Text("অর্ডার নিশ্চিত করুন") } }
                    if (orderMessage.isNotBlank()) item { Text(orderMessage, color = Green, fontWeight = FontWeight.Bold) }
                    item { Text("নোট: UPI এখানে শুধু ডেমো নির্বাচন; টাকা কাটা বা পেমেন্ট যাচাই হয় না।", color = Color.Gray, fontSize = 12.sp) }
                }
                else -> LazyColumn(Modifier.padding(padding).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Text("আজকের বাজার", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Green)
                                Text("এখন শুধু শসা ও ঝিঙে পাওয়া যাচ্ছে")
                            }
                        }
                    }
                    item { ProductCard("🥒", "শসা", cucumberPrice, cucumberQty, { cucumberQty = (cucumberQty - 1).coerceAtLeast(0) }, { cucumberQty++ }) }
                    item { ProductCard("🥬", "ঝিঙে", ridgePrice, ridgeQty, { ridgeQty = (ridgeQty - 1).coerceAtLeast(0) }, { ridgeQty++ }) }
                    item { Text("দাম প্রতি কেজি। Admin থেকে ডেমো দাম পরিবর্তন করা যাবে।", color = Color.Gray, fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun ProductCard(emoji: String, name: String, price: Int, qty: Int, minus: () -> Unit, plus: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 42.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("₹$price / কেজি", color = Green, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = minus) { Icon(Icons.Default.Remove, contentDescription = "কমাও") }
            Text("$qty", fontWeight = FontWeight.Bold)
            IconButton(onClick = plus) { Icon(Icons.Default.Add, contentDescription = "বাড়াও") }
        }
    }
}

@Composable
private fun PriceEditor(name: String, price: Int, onChange: (Int) -> Unit) {
    var value by remember(price) { mutableStateOf(price.toString()) }
    Card {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text("$name-এর দাম (₹/কেজি)", fontWeight = FontWeight.Bold)
            OutlinedTextField(value = value, onValueChange = { value = it.filter(Char::isDigit) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = { value.toIntOrNull()?.let { if (it > 0) onChange(it) } }) { Text("দাম আপডেট") }
        }
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = if (selected) Pale else MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Text(label)
        }
    }
}
